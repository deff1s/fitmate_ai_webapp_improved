import React, { useState } from "react";

const fields = ["gender", "age", "weight", "height", "goal", "period"];

export default function Form() {
  const [formData, setFormData] = useState({
    gender: "",
    age: "",
    weight: "",
    height: "",
    goal: "",
    period: "",
    photo: null,
  });
  const [submitted, setSubmitted] = useState(false);

  const filledCount = fields.reduce((cnt, key) => (formData[key] ? cnt + 1 : cnt), 0);
  const progress = Math.round((filledCount / fields.length) * 100);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData({
      ...formData,
      [name]: files ? files[0] : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    setSubmitted(true);
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h2 className="text-center text-lg font-semibold mb-4">Твоя трансформация начинается здесь</h2>

      <div className="mb-4">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-primary h-2 rounded-full" style={{ width: `${progress}%` }}></div>
        </div>
        <p className="text-right text-sm mt-1">{progress}%</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <select
          name="gender"
          value={formData.gender}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
          required
        >
          <option value="">Выберите пол</option>
          <option value="male">Мужской</option>
          <option value="female">Женский</option>
        </select>

        <input
          type="number"
          name="age"
          placeholder="Возраст"
          value={formData.age}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
          required
        />

        <input
          type="number"
          name="weight"
          placeholder="Вес (кг)"
          value={formData.weight}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
          required
        />

        <input
          type="number"
          name="height"
          placeholder="Рост (см)"
          value={formData.height}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
          required
        />

        <select
          name="goal"
          value={formData.goal}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
          required
        >
          <option value="">Цель</option>
          <option value="loss">Похудение</option>
          <option value="gain">Набор массы</option>
          <option value="maintain">Поддержание</option>
        </select>

        <select
          name="period"
          value={formData.period}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
          required
        >
          <option value="">Срок расчета</option>
          <option value="1w">1 неделя</option>
          <option value="2w">2 недели</option>
          <option value="3w">3 недели</option>
          <option value="4w">4 недели</option>
          <option value="2m">2 месяца</option>
          <option value="3m">3 месяца</option>
        </select>

        <div>
          <input
            type="file"
            name="photo"
            onChange={handleChange}
            className="w-full border border-gray-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-primary"
            accept="image/*"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-primary to-red-400 text-white p-2 rounded hover:opacity-90 transition"
        >
          Рассчитать
        </button>
      </form>

      {formData.photo && (
        <div className="mt-4 text-center">
          <img
            src={URL.createObjectURL(formData.photo)}
            alt="Preview"
            className="mx-auto w-32 h-32 object-cover rounded-full border"
          />
        </div>
      )}

      {submitted && (
        <div className="mt-4 p-3 border border-gray-300 rounded bg-gray-50">
          <p className="font-medium text-center">Отлично! Следующий шаг: ждите прогноз.</p>
        </div>
      )}

      <p className="mt-6 text-center italic text-sm text-gray-500">«Твое тело — твое дело. Сделай шаг сегодня.»</p>
    </div>
}
