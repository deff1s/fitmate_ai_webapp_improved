import React from "react";

export default function Calendar() {
  return (
    <div className="p-4 max-w-md mx-auto text-center">
      <h2 className="text-xl font-bold mb-2 text-primary">Календарь</h2>
      <p>Здесь будет ваш тренировочный календарь.</p>
    </div>
}
