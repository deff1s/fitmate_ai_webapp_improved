import React from "react";

export default function Profile() {
  return (
    <div className="p-4 max-w-md mx-auto text-center">
      <h2 className="text-xl font-bold mb-2 text-primary">Профиль</h2>
      <p>Здесь будет информация о пользователе и его прогресс.</p>
    </div>
}
